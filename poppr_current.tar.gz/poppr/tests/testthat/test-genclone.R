context("Genclone coercion tests")

test_that("A genclone object contains a genind object", {

	data(partial_clone, package = "poppr")
	pc <- as.genclone(partial_clone)
	expect_that(slotNames(partial_clone), equals(slotNames(pc)[-1]))
	expect_that(partial_clone@tab, equals(pc@tab))
	expect_that(partial_clone@loc.names, is_identical_to(pc@loc.names))
	expect_that(partial_clone@loc.nall, is_identical_to(pc@loc.nall))
	expect_that(partial_clone@all.names, is_equivalent_to(pc@all.names))
	expect_that(partial_clone@ind.names, is_identical_to(pc@ind.names))
	expect_that(partial_clone@pop, is_identical_to(pc@pop))
	expect_that(popNames(partial_clone), is_identical_to(popNames(pc)))
	expect_that(partial_clone@ploidy, is_identical_to(pc@ploidy))
	expect_that(partial_clone@type, is_identical_to(pc@type))
	expect_that(partial_clone@other, is_identical_to(pc@other))
	expect_that(pc@mlg[], is_identical_to(mlg.vector(partial_clone)))
})

test_that("Hierarchy methods work for genclone objects.", {
  data(Aeut, package = "poppr")
  agc <- as.genclone(Aeut)
  strata(agc) <- other(agc)$population_hierarchy
  expect_that(length(strata(agc)), equals(3))
  expect_that(popNames(agc), equals(c("Athena", "Mt. Vernon")))
  expect_that({agcsplit <- splitStrata(agc, ~Pop/Subpop)}, gives_warning())
  expect_that(strata(agcsplit), equals(strata(agc, ~Pop/Subpop, combine = FALSE)))
  expect_that(strata(agc, value = strata(agcsplit)), equals(agcsplit))
  nameStrata(agcsplit) <- ~Field/Core
  expect_that(names(strata(agcsplit)), equals(c("Field", "Core")))
  setPop(agc) <- ~Pop/Subpop
  expect_that(popNames(agc), equals(c("Athena_1", "Athena_2", "Athena_3", 
                                      "Athena_4", "Athena_5", "Athena_6", 
                                      "Athena_7", "Athena_8", "Athena_9", 
                                      "Athena_10", "Mt. Vernon_1", 
                                      "Mt. Vernon_2", "Mt. Vernon_3", 
                                      "Mt. Vernon_4", "Mt. Vernon_5", 
                                      "Mt. Vernon_6", "Mt. Vernon_7", 
                                      "Mt. Vernon_8")))
})
